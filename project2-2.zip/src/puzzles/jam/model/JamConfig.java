package puzzles.jam.model;

// TODO: implement your JamConfig for the common solver

public class JamConfig {
}

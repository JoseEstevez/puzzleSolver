package puzzles.jam.model;

public class JamClientData {
}

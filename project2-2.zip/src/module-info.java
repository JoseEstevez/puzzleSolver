module BFSPuzzleSolver {
    requires transitive javafx.controls;
    exports puzzles.common;
    exports puzzles.hoppers.gui;
    exports puzzles.hoppers.model;
    exports puzzles.jam.gui;
    exports puzzles.jam.model;
}